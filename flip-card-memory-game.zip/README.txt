A Pen created at CodePen.io. You can find this one at https://codepen.io/zerospree/pen/bNWbvW.

 Super old project I remembered about. Just thought I'd share it with you awesome CodePen people. Have some fun :)

The game will save your stats locally, via localStorage.

Featured on CSS Design Awards: http://www.cssdesignawards.com/articles/design-dev-feed-6/194/